
<?php $__env->startSection('title'); ?>
    lorem ipsum
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="bg-half-170 d-table w-100"
        style="background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('<?php echo e(asset('vendor/smpn17/images/banner1.png')); ?>'); background-position: center center; background-size: cover;"
        id="home">
        <div class="container">
            <div class="row position-relative align-items-center pt-4">
                <div class="col-lg-7 offset-lg-5">
                    <div class="title-heading studio-home rounded bg-white shadow mt-5">
                        <h1 class="heading mb-3"><?php echo e(config('app.name')); ?></h1>
                        <p class="para-desc text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit..</p>
                        <div class="mt-4"><a href="ppdb.html" class="btn btn-primary mt-2 mr-2"><i
                                    class="mdi mdi-handshake"></i> Info PPDB </a><a href="profil.html"
                                class="btn btn-outline-primary mt-2"><i class="mdi mdi-book-outline"></i> Profil
                                Sekolah </a></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="section">
        <div class="container">
            <div class="row align-items-center py-2">
                <div class="col-lg-5 col-md-6 col-12"><img src="<?php echo e(asset('vendor/smpn17/images/sejarah.png')); ?>"
                        class="img-fluid rounded" alt="" /></div>
                <div class="col-lg-7 col-md-6 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <div class="section-title ml-lg-4">
                        <h4 class="title mb-4">Sejarah Singkat</h4>
                        <p class="text-muted">Lorem ipsum dolor sit amet,
                            consectetur
                            adipiscing elit. Aenean congue vulputate leo a ullamcorper. Ut mattis lorem sed lacus
                            auctor, in dictum nisl tempus. Sed non metus in massa imperdiet sodales. Sed ac pretium
                            magna. Morbi at ipsum ligula. Quisque volutpat dolor nec nibh condimentum, sed ultricies
                            mi
                            ornare. Praesent non dui id tortor efficitur dapibus sed vel dolor. </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row align-items-center">
                <div class="d-flex flex-row-reverse bg-light py-3">
                    <div class="col-lg-5 col-md-6 col-6">
                        <img src="<?php echo e(asset('vendor/smpn17/images/sejarah.png')); ?>" class="img-fluid rounded" alt="">
                    </div>
                    <div class="col-lg-7 col-md-6 col-6 mt-4 mt-sm-0 pt-2 pt-sm-0">
                        <div class="section-title ml-lg-4">
                            <h4 class="title mb-4">Sejarah Singkat</h4>
                            <p class="text-muted"><?php echo e(config('app.name')); ?>, berdiri Lorem ipsum dolor sit amet,
                                consectetur
                                adipiscing elit. Aenean congue vulputate leo a ullamcorper. Ut mattis lorem sed lacus
                                auctor, in dictum nisl tempus. Sed non metus in massa imperdiet sodales. Sed ac pretium
                                magna. Morbi at ipsum ligula. Quisque volutpat dolor nec nibh condimentum, sed ultricies
                                mi
                                ornare. Praesent non dui id tortor efficitur dapibus sed vel dolor. </p>
                            <a href="sejarah.html" class="btn btn-primary mt-3">Selengkapnya</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container mt-100 mt-60">
            <div class="row">
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="card features fea-primary rounded p-4 position-relative overflow-hidden border-0 shadow">
                        <span class="h1 icon2 text-primary"><i class="uil uil-briefcase"></i></span>
                        <div class="card-body p-0 content">
                            <h5>Visi</h5>
                            <p class="para text-muted mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                                Aenean congue vulputate leo a ullamcorper. Ut mattis lorem sed lacus auctor, in dictum
                                nisl tempus. Sed non metus in massa imperdiet sodales.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <div class="card features fea-primary rounded p-4 position-relative overflow-hidden border-0 shadow">
                        <span class="h1 icon2 text-primary"><i class="uil uil-rocket"></i></span>
                        <div class="card-body p-0 content">
                            <h5>Misi</h5>
                            <ol class="para text-muted mb-0 pl-3">
                                <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                                </li>
                                <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                                <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                                <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                            </ol>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12 mt-4 mt-lg-0 pt-2 pt-lg-0">
                    <div class="card features fea-primary rounded p-4 position-relative overflow-hidden border-0 shadow">
                        <span class="h1 icon2 text-primary"><i class="uil uil-crosshairs"></i></span>
                        <div class="card-body p-0 content">
                            <h5>Tujuan</h5>
                            <ol class="para text-muted mb-0 pl-3">
                                <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                                <li>TLorem ipsum dolor sit amet, consectetur adipiscing elit.
                                </li>
                                <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                                <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="section bg-light">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 text-center">
                    <div class="section-title mb-0 pb-2">
                        <h4 class="title mb-0">Artikel Terbaru</h4>
                        <p class="text-muted para-desc mx-auto mb-0">Ayo baca artikel terbaru kita
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <!-- Post list:start -->
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-4 col-md-6 mt-4 pt-2">
                        <div class="card blog rounded border-0 shadow">
                            <div class="position-relative">
                                <!-- thumbnail:start -->
                                <?php if(file_exists(public_path($post->thumbnail))): ?>
                                    <!-- true -->
                                    <img class="card-img-top rounded-top" src="<?php echo e(asset($post->thumbnail)); ?>"
                                        alt="<?php echo e($post->title); ?>">
                                <?php else: ?>
                                    <!-- else -->
                                    <img class="img-fluid rounded" src="http://placehold.it/750x300"
                                        alt="<?php echo e($post->title); ?>">
                                <?php endif; ?>
                                <!-- thumbnail:end -->
                                <div class="overlay rounded-top bg-dark"></div>
                            </div>
                            <div class="card-body content">
                                <h5><a href="<?php echo e(route('blog.posts.detail', ['slug' => $post->slug])); ?>"
                                        class="card-title title text-dark"><?php echo e($post->title); ?></a></h5>
                                <p class="text-muted"><?php echo e($post->description); ?>.. </p>
                                <div class="post-meta d-flex justify-content-between mt-3">
                                    <a href="<?php echo e(route('blog.posts.detail', ['slug' => $post->slug])); ?>"
                                        class="text-muted readmore">Baca Selengkapnya <i
                                            class="mdi mdi-chevron-right"></i></a>
                                </div>
                            </div>
                            <div class="author"><small class="text-light user d-block"><i class="mdi mdi-account"></i>
                                    Administrator</small><small class="text-light date"><i
                                        class="mdi mdi-calendar-check"></i>
                                    <?php echo e($post->created_at->format('Y-m-d H:i:s')); ?>

                                </small></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <!-- empty -->
                    <h3 class="text-center">
                        <?php echo e(trans('blog.no_data.posts')); ?>

                    </h3>
                <?php endif; ?>
                <!-- Post list:end -->

                <div class="col-12 mt-4 pt-2">
                    <a href="<?php echo e(route('blog.home')); ?>" class="btn btn-primary">Selengkapnya <i
                            class="mdi mdi-chevron-right">
                        </i></a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smpn17tegal\resources\views/landing/index.blade.php ENDPATH**/ ?>