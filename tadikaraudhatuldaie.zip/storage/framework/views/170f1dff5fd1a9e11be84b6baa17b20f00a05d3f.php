<header id="topnav" class="defaultscroll sticky bg-white">
    <div class="container">
        <div><a class="logo" href="smpn17-tegal.sch.id" title="<?php echo e(config('app.name')); ?>">SMPN 17 Kota
                Tegal</a></div>
        <div class="buy-button"><span rel="noindex, nofollow" target="_blank" class="btn btn-primary">Telp :
                (0283) 358848</span></div>
        <div class="menu-extras">
            <div class="menu-item">
                <a class="navbar-toggle" href="smpn17-tegal.sch.id">
                    <div class="lines"><span></span><span></span><span></span></div>
                </a>
            </div>
        </div>
        <div id="navigation">
            <ul class="navigation-menu">
                <li><a href="<?php echo e(route('landing.index')); ?>">Beranda</a></li>
                <li><a href="<?php echo e(route('blog.home')); ?>">Artikel</a></li>
                
                <li><a href="<?php echo e(route('landing.contact')); ?>">Hubungi Kami</a></li>
            </ul>
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\smpn17tegal\resources\views/layouts/_landing/_navbar.blade.php ENDPATH**/ ?>