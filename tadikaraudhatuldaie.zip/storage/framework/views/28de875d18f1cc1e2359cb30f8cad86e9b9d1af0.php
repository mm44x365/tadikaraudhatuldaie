
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('roles.title.index')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo e(Breadcrumbs::render('roles')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- section:content -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6">
                            <form action="<?php echo e(route('roles.index')); ?>" method="GET">
                                <div class="input-group">
                                    <input name="keyword" value="<?php echo e(request()->get('keyword')); ?>" type="search"
                                        class="form-control"
                                        placeholder="<?php echo e(trans('roles.form_control.input.search.placeholder')); ?>">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="submit">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-6">
                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_create')): ?>
                                <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary float-right" role="button">
                                    <?php echo e(trans('roles.button.create.value')); ?>

                                    <i class="fas fa-plus-square"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <!-- list role -->
                        <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li
                                class="list-group-item list-group-item-action d-flex justify-content-between align-items-center pr-0">
                                <label class="mt-auto mb-auto">
                                    <?php echo e($role->name); ?>

                                </label>
                                <div>
                                    <!-- detail -->
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_detail')): ?>
                                        <a href="<?php echo e(route('roles.show', ['role' => $role])); ?>" class="btn btn-sm btn-primary"
                                            role="button">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    <?php endif; ?>
                                    <!-- edit -->
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_update')): ?>
                                        <a href="<?php echo e(route('roles.edit', ['role' => $role])); ?>" class="btn btn-sm btn-info"
                                            role="button">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    <?php endif; ?>
                                    <!-- delete -->
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_delete')): ?>
                                        <form class="d-inline" role="alert"
                                            action="<?php echo e(route('roles.destroy', ['role' => $role])); ?>" method="POST"
                                            alert-text="<?php echo e(trans('roles.alert.delete.message.confirm', ['name' => $role->name])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>
                                <?php if(request()->get('keyword')): ?>
                                    <strong><?php echo e(trans('roles.label.no_data.search', ['keyword' => request()->get('keyword')])); ?></strong>
                                <?php else: ?>
                                    <strong><?php echo e(trans('roles.label.no_data.fetch')); ?></strong>
                                <?php endif; ?>
                            </p>
                        <?php endif; ?>
                        <!-- list role -->
                    </ul>
                </div>
                <?php if($roles->hasPages()): ?>
                    <div class="card-footer">
                        <?php echo e($roles->links('vendor.pagination.bootstrap-4')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript-internal'); ?>
    <script>
        $(document).ready(function() {
            // event delete role
            $("form[role='alert']").submit(function(event) {
                event.preventDefault();
                Swal.fire({
                    title: "<?php echo e(trans('roles.alert.delete.title')); ?>",
                    text: $(this).attr('alert-text'),
                    icon: 'warning',
                    allowOutsideClick: false,
                    showCancelButton: true,
                    cancelButtonText: "<?php echo e(trans('roles.button.cancel.value')); ?>",
                    reverseButtons: true,
                    confirmButtonText: "<?php echo e(trans('roles.button.delete.value')); ?>",
                }).then((result) => {
                    if (result.isConfirmed) {
                        event.target.submit();
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dudu\resources\views/roles/index.blade.php ENDPATH**/ ?>