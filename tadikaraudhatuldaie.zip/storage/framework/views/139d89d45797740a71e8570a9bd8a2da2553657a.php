

<?php $__env->startSection('title'); ?>
    <?php echo e(trans('tags.title.index')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo e(Breadcrumbs::render('tags')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- section:content -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6">
                            <form action="" method="GET">
                                <div class="input-group">
                                    <input name="keyword" type="search" class="form-control"
                                        placeholder="<?php echo e(trans('tags.form_control.input.search.placeholder')); ?>">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="submit">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-6">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tag_create')): ?>
                                <a href="<?php echo e(route('tags.create')); ?>" class="btn btn-primary float-right" role="button">
                                    <?php echo e(trans('tags.button.create.value')); ?>

                                    <i class="fas fa-plus-square"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <!-- list tag -->
                        <?php if(count($tags)): ?>
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- tag list -->
                                <li
                                    class="list-group-item list-group-item-action d-flex justify-content-between align-items-center pr-0">
                                    <label class="mt-auto mb-auto">
                                        <?php echo e($tag->title); ?>

                                    </label>
                                    <div>
                                        <!-- edit -->
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tag_update')): ?>
                                            <a href="<?php echo e(route('tags.edit', ['tag' => $tag])); ?>" class="btn btn-sm btn-info"
                                                role="button">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        <?php endif; ?>
                                        <!-- delete -->
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tag_delete')): ?>
                                            <form class="d-inline" role="alert"
                                                action="<?php echo e(route('tags.destroy', ['tag' => $tag])); ?>" method="POST"
                                                alert-text="<?php echo e(trans('tags.alert.delete.message.confirm', ['title' => $tag->title])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </li>
                                <!-- end  tag list -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p>
                                <strong>
                                    <?php echo e(trans('tags.label.no_data.fetch')); ?>

                                </strong>
                            </p>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript-internal'); ?>
    <script>
        $(document).ready(function() {
            // event delete tag
            $("form[role='alert']").submit(function(event) {
                event.preventDefault();
                Swal.fire({
                    title: "<?php echo e(trans('tags.alert.delete.title')); ?>",
                    text: $(this).attr('alert-text'),
                    icon: 'warning',
                    allowOutsideClick: false,
                    showCancelButton: true,
                    cancelButtonText: "<?php echo e(trans('tags.button.cancel.value')); ?>",
                    reverseButtons: true,
                    confirmButtonText: "<?php echo e(trans('tags.button.delete.value')); ?>",
                }).then((result) => {
                    if (result.isConfirmed) {
                        event.target.submit();
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dudu\resources\views/tags/index.blade.php ENDPATH**/ ?>