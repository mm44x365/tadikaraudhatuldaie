<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid">
       <div class="d-flex align-items-center justify-content-between small">
          <div class="text-muted">Copyright &copy; Your Website 2021</div>
          <div>
             <a href="#">Privacy Policy</a>
             &middot;
             <a href="#">Terms &amp; Conditions</a>
          </div>
       </div>
    </div>
 </footer><?php /**PATH C:\xampp\htdocs\smpn17tegal\resources\views/layouts/_auth/footer.blade.php ENDPATH**/ ?>