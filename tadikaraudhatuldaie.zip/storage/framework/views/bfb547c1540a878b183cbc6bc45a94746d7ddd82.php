
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('posts.title.index')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo e(Breadcrumbs::render('posts')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6">
                            <form action="" method="GET" class="form-inline form-row">
                                <div class="col">
                                    <div class="input-group mx-1">
                                        <label
                                            class="font-weight-bold mr-2"><?php echo e(trans('posts.form_control.select.status.label')); ?></label>
                                        <select name="status" class="custom-select">
                                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value); ?>"
                                                    <?php echo e($statusSelected == $value ? 'selected' : null); ?>><?php echo e($label); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="input-group-append">
                                            <button class="btn btn-primary"
                                                type="submit"><?php echo e(trans('posts.button.apply.value')); ?></button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="input-group mx-1">
                                        <input name="keyword" value="<?php echo e(request()->get('keyword')); ?>" type="search"
                                            class="form-control"
                                            placeholder="<?php echo e(trans('posts.form_control.input.search.placeholder')); ?>">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="submit">
                                                <i class="fas fa-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-6">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post_create')): ?>
                                <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary float-right" role="button">
                                    <?php echo e(trans('posts.button.create.value')); ?>

                                    <i class="fas fa-plus-square"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <!-- list post -->
                        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="card my-2">
                                <div class="card-body">
                                    <h5><?php echo e($post->title); ?></h5>
                                    <p>
                                        
                                        <?php echo e($post->description); ?>

                                    </p>
                                    <div class="float-right">
                                        <!-- detail -->
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post_detail')): ?>
                                            <a href="<?php echo e(route('posts.show', ['post' => $post])); ?>"
                                                class="btn btn-sm btn-primary" role="button">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        <?php endif; ?>
                                        <!-- edit -->
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post_update')): ?>
                                            <a href="<?php echo e(route('posts.edit', ['post' => $post])); ?>" class="btn btn-sm btn-info"
                                                role="button">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        <?php endif; ?>
                                        <!-- delete -->
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post_delete')): ?>
                                            <form class="d-inline" role="alert"
                                                alert-text="<?php echo e(trans('posts.alert.delete.message.confirm', ['title' => $post->title])); ?>"
                                                action="<?php echo e(route('posts.destroy', ['post' => $post])); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>
                                <strong>
                                    <?php if(request()->get('keyword')): ?>
                                        <?php echo e(trans('posts.label.no_data.search', ['keyword' => request()->get('keyword')])); ?>

                                    <?php else: ?>
                                        <?php echo e(trans('posts.label.no_data.fetch')); ?>

                                    <?php endif; ?>
                                </strong>
                            </p>
                        <?php endif; ?>
                    </ul>
                </div>
                <?php if($posts->hasPages()): ?>
                    <div class="card-footer">
                        <?php echo e($posts->links('vendor.pagination.bootstrap-4')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript-internal'); ?>
    <script>
        $(document).ready(function() {
            // event delete tag
            $("form[role='alert']").submit(function(event) {
                event.preventDefault();
                Swal.fire({
                    title: "<?php echo e(trans('posts.alert.delete.title')); ?>",
                    text: $(this).attr('alert-text'),
                    icon: 'warning',
                    allowOutsideClick: false,
                    showCancelButton: true,
                    cancelButtonText: "<?php echo e(trans('posts.button.cancel.value')); ?>",
                    reverseButtons: true,
                    confirmButtonText: "<?php echo e(trans('posts.button.delete.value')); ?>",
                }).then((result) => {
                    if (result.isConfirmed) {
                        event.target.submit();
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smpn17tegal\resources\views/posts/index.blade.php ENDPATH**/ ?>