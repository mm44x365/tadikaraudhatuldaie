

<?php $__env->startSection('title'); ?>
    <?php echo e(trans('categories.title.index')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo e(Breadcrumbs::render('categories')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- section:content -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6">
                            <form action="<?php echo e(route('categories.index')); ?>" method="GET">
                                <div class="input-group">
                                    <input name="keyword" type="search" class="form-control"
                                        placeholder="<?php echo e(trans('categories.form_control.input.search.placeholder')); ?>"
                                        value="<?php echo e(request()->get('keyword')); ?>">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="submit">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-6">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category_create')): ?>
                                <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary float-right" role="button">
                                    <?php echo e(trans('categories.button.create.value')); ?>

                                    <i class="fas fa-plus-square"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <!-- list category -->
                        <?php if(count($categories)): ?>
                            <?php echo $__env->make('categories._category-list', [
                                'categories' => $categories,
                                'count' => 0,
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php else: ?>
                            <p>
                                <strong>
                                    <?php if(request()->get('keyword')): ?>
                                        <?php echo e(trans('categories.label.no_data.search', ['keyword' => request()->get('keyword')])); ?>

                                    <?php else: ?>
                                        <?php echo e(trans('categories.label.no_data.fetch')); ?>

                                    <?php endif; ?>
                                </strong>
                            </p>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="card-footer">
                    <?php if($categories->hasPages()): ?>
                        <?php echo e($categories->links('vendor.pagination.bootstrap-4')); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript-internal'); ?>
    <script>
        $(document).ready(function() {
            // event delete category
            $("form[role='alert']").submit(function(event) {
                {
                    event.preventDefault();
                    Swal.fire({
                        title: $(this).attr('alert-title'),
                        text: $(this).attr('alert-text'),
                        icon: 'warning',
                        allowOutsideClick: false,
                        showCancelButton: true,
                        cancelButtonText: $(this).attr('alert-btn-cancel'),
                        reverseButtons: true,
                        confirmButtonText: $(this).attr('alert-btn-yes'),
                    }).then((result) => {
                        if (result.isConfirmed) {
                            event.target.submit();
                        }
                    });
                }
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dudu\resources\views/categories/index.blade.php ENDPATH**/ ?>