<nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
    <a class="navbar-brand" href="#">
       <!-- show app name -->
       <?php echo e(config('app.name')); ?>

    </a>
    <button class="btn btn-link btn-sm order-1 order-lg-0" id="sidebarToggle" href="#">
       <i class="fas fa-bars"></i>
    </button>
    <ul class="navbar-nav ml-auto">
      
       <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="language" href="#" role="button" data-toggle="dropdown"
             aria-haspopup="true" aria-expanded="false">
             <!-- lang:id -->
             <?php switch(app()->getLocale()):
             case ('id'): ?>
             <i class="flag-icon flag-icon-id"></i>
                <?php break; ?>
             <?php case ('en'): ?>
            <i class="flag-icon flag-icon-gb"></i>
                <?php break; ?>
             <?php default: ?>        
             <?php endswitch; ?>
             <?php echo e(strToupper(app()->getLocale())); ?>

          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="language">
             <a class="dropdown-item" href="<?php echo e(route('localization.switch',['language' => 'id'])); ?>"><?php echo e(trans('localization.id')); ?></a>
             <a class="dropdown-item" href="<?php echo e(route('localization.switch',['language' => 'en'])); ?>"><?php echo e(trans('localization.en')); ?></a>
          </div>
       </li>
       <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="userDropdown" href="#" role="button" data-toggle="dropdown"
             aria-haspopup="true" aria-expanded="false">
             <i class="fas fa-user fa-fw"></i>
             <!-- show username -->
             <?php echo e(Auth::user()->name); ?>

          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
             <a class="dropdown-item" href="#"><?php echo e(trans('dashboard.link.profile')); ?></a>
             <div class="dropdown-divider"></div>
             <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault();
                  document.getElementById('logout-form').submit();">
              <?php echo e(trans('dashboard.link.logout')); ?>

            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                  <?php echo csrf_field(); ?>
            </form>
          </div>
       </li>
    </ul>
 </nav>
 <?php /**PATH C:\xampp\htdocs\smpn17tegal\resources\views/layouts/_dashboard/navbar.blade.php ENDPATH**/ ?>