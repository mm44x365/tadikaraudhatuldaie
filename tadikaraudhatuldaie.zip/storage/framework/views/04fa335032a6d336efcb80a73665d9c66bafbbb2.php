
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('posts.title.detail')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo e(Breadcrumbs::render('detail_posts', $post)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- content -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <?php if(file_exists(public_path($post->thumbnail))): ?>
                        <!-- 	thumbnail:true -->
                        <div class="post-tumbnail" style="background-image: url('<?php echo e($post->thumbnail); ?>');">
                        </div>
                    <?php else: ?>
                        <!-- thumbnail:false -->
                        <svg class="img-fluid" width="100%" height="400" xmlns="http://www.w3.org/2000/svg"
                            preserveAspectRatio="xMidYMid slice" focusable="false" role="img">
                            <rect width="100%" height="100%" fill="#868e96"></rect>
                            <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle"
                                fill="#dee2e6" dy=".3em" font-size="24">
                                <?php echo e($post->title); ?>

                            </text>
                        </svg>
                    <?php endif; ?>
                    <!-- title -->
                    <h2 class="my-1">
                        <?php echo e($post->title); ?>

                    </h2>
                    <!-- description -->
                    <p class="text-justify">
                        <?php echo e($post->description); ?>

                    </p>
                    <!-- categories -->
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge badge-primary"><?php echo e($category->title); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- content -->
                    <div class="py-1">
                        <?php echo $post->content; ?>

                    </div>
                    <!-- tags  -->
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge badge-info">#<?php echo e($category->title); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-end">
                        <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-primary mx-1" role="button">
                            <?php echo e(trans('posts.button.back.value')); ?>

                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css-internal'); ?>
    <!-- style -->
    <style>
        .post-tumbnail {
            width: 100%;
            height: 400px;
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dudu\resources\views/posts/detail.blade.php ENDPATH**/ ?>