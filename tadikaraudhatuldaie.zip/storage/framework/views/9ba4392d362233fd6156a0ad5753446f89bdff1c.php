 <!-- Navbar Start -->
 <div class="container-fluid bg-light position-relative shadow">
     <nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0 px-lg-5">
         <a href="<?php echo e(route('landing.index')); ?>" class="navbar-brand font-weight-bold text-secondary"
             style="font-size: 35px;">
             <img style="margin: auto;" src="<?php echo e(asset('vendor/tadika/img/logo.png')); ?>" height="45"
                 alt="<?php echo e(config('app.name')); ?>">
             <span class="text-primary"><?php echo e(config('app.name')); ?></span>
         </a>
         <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
             <span class="navbar-toggler-icon"></span>
         </button>
         <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
             <div class="navbar-nav font-weight-bold mx-auto py-0">
                 <a href="<?php echo e(route('landing.index')); ?>"
                     class="nav-item nav-link <?php echo e(set_active(['landing.index'])); ?>">Home</a>
                 
                 
                 <a href="<?php echo e(route('blog.home')); ?>"
                     class="nav-item nav-link <?php echo e(set_active(['blog.home'])); ?>">Article</a>
                 
                 <a href="<?php echo e(route('landing.contact')); ?>"
                     class="nav-item nav-link <?php echo e(set_active(['landing.contact'])); ?>">Contact</a>
             </div>
         </div>
     </nav>
 </div>
 <!-- Navbar End -->
<?php /**PATH C:\xampp\htdocs\tadikaraudhatuldaie\resources\views/layouts/_landing/_navbar.blade.php ENDPATH**/ ?>