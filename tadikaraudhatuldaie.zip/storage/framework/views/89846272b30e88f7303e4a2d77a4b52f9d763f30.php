<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-12 mb-0 mb-md-4 pb-0 pb-md-2">
                <a class="logo" href="smpn17-tegal.sch.id" title="<?php echo e(config('app.name')); ?>"><?php echo e(config('app.name')); ?></a>
                <p class="mt-4">Bertaqwa, Profesional, Sesuai Perkembangan IPTEK.</p>
                <ul class="list-unstyled social-icon social mb-0 mt-4">
                    <li class="list-inline-item"><a href="https://www.facebook.com/" class="rounded" target="_blank"><i
                                data-feather="facebook" class="fea icon-sm fea-social"></i></a> <a
                            href="https://www.instagram.com/" class="rounded" target="_blank"><i
                                data-feather="instagram" class="fea icon-sm fea-social"></i></a> <a
                            href="https://twitter.com" class="rounded" target="_blank"><i data-feather="twitter"
                                class="fea icon-sm fea-social"></i></a> <a href="https://www.youtube.com/"
                            class="rounded" target="_blank"><i data-feather="youtube"
                                class="fea icon-sm fea-social"></i></a>
                    </li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                <h4 class="text-light footer-head">Tautan</h4>
                <ul class="list-unstyled footer-list mt-4">
                    <li><a rel="noindex, nofollow" class="text-foot" target="_blank"
                            href="<?php echo e(route('landing.index')); ?>">Beranda</a></li>
                    <li><a rel="noindex, nofollow" class="text-foot" target="_blank"
                            href="<?php echo e(route('blog.home')); ?>">Artikel</a></li>
                    <li><a rel="noindex, nofollow" class="text-foot" target="_blank"
                            href="<?php echo e(route('landing.contact')); ?>">Hubungi Kami</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">

            </div>
            <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                <h4 class="text-light footer-head">Informasi Kontak</h4>
                <ul class="list-unstyled footer-list mt-4">
                    <li><span class="text-foot" rel="noindex, nofollow" target="_blank"><i
                                class="mdi mdi-google-maps mr-1"></i> Jl. Gatot Subroto No.13, Sumurpanggang, Kec.
                            Margadana, Kota Tegal, Jawa Tengah 52141</span></li>
                    <li><span class="text-foot"><i class="mdi mdi-phone mr-1"></i> (0283) 358848</span></li>
                    <li><span class="text-foot"><i class="mdi mdi-fax mr-1"></i> (0283) 358848</span></li>
                    <li><span class="text-foot"><i class="mdi mdi-email mr-1"></i> mail@gmail.com</span></li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<footer class="footer footer-bar">
    <div class="container text-center">
        <div class="row align-items-center">
            <div class="col-sm-12">
                <div class="text-sm-left">
                    <p class="mb-0">© 2022 <?php echo e(config('app.name')); ?>. All Rights Reserved.</p>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\smpn17tegal\resources\views/layouts/_landing/_footer.blade.php ENDPATH**/ ?>