
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('blog.title.category', ['title' => $category->title])); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="bg-half bg-light d-table w-100">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12 text-center">
                    <div class="page-next-level">
                        <h4 class="title">Artikel</h4>
                        <div class="page-next">
                            <nav aria-label="breadcrumb" class="d-inline-block">
                                <?php echo e(Breadcrumbs::render('blog_posts_category', $category->title)); ?>

                                
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="position-relative">
        <div class="shape overflow-hidden text-white">
            <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
            </svg>
        </div>
    </div>
    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-6">
                    <div class="row">
                        <!-- Post list:start -->
                        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-lg-6 col-md-12 mb-4 pb-2 post-item">
                                <div class="card blog rounded border-0 shadow">
                                    <div class="position-relative">
                                        <!-- thumbnail:start -->
                                        <?php if(file_exists(public_path($post->thumbnail))): ?>
                                            <!-- true -->
                                            <img class="card-img-top rounded-top" src="<?php echo e(asset($post->thumbnail)); ?>"
                                                alt="<?php echo e($post->title); ?>">
                                        <?php else: ?>
                                            <!-- else -->
                                            <img class="img-fluid rounded" src="http://placehold.it/750x300"
                                                alt="<?php echo e($post->title); ?>">
                                        <?php endif; ?>
                                        <!-- thumbnail:end -->
                                        <div class="overlay rounded-top bg-dark"></div>
                                    </div>
                                    <div class="card-body content">
                                        <h5><a href="<?php echo e(route('blog.posts.detail', ['slug' => $post->slug])); ?>"
                                                class="card-title title text-dark"><?php echo e($post->title); ?></a></h5>
                                        <p class="text-muted"><?php echo e($post->description); ?>.. </p>
                                        <div class="post-meta d-flex justify-content-between mt-3 float-right">
                                            <a href="<?php echo e(route('blog.posts.detail', ['slug' => $post->slug])); ?>"
                                                class="text-muted readmore">Baca
                                                Selengkapnya<i class="mdi mdi-chevron-right"></i></a>
                                        </div>
                                    </div>
                                    <div class="author"><small class="text-light user d-block"><i
                                                class="mdi mdi-account"></i>
                                            Administrator</small><small class="text-light date"><i
                                                class="mdi mdi-calendar-check"></i>
                                            <?php echo e($post->created_at->format('Y-m-d H:i:s')); ?></small></div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <!-- empty -->
                            <h3 class="text-center">
                                <?php echo e(trans('blog.no_data.posts')); ?>

                            </h3>
                        <?php endif; ?>
                        <!-- Post list:end -->
                    </div>
                    <!-- pagination:start -->
                    <?php if($posts->hasPages()): ?>
                        <div class="row">
                            <div class="col">
                                <?php echo e($posts->links('vendor.pagination.bootstrap-4')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <!-- pagination:end -->
                </div>
                <div class="col-lg-4 col-md-6 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <div class="card border-0 sidebar sticky-bar rounded shadow">
                        <div class="card-body">
                            <div id="search-outside">
                                <div class="widget mt-4 pb-2">
                                    <h4 class="widget-title"> <?php echo e(trans('blog.widget.categories')); ?></h4>
                                    <ul class="list-unstyled">
                                        <li>
                                            <?php if($category->slug == $categoryRoot->slug): ?>
                                                <?php echo e($categoryRoot->title); ?>

                                            <?php else: ?>
                                                <a
                                                    href="<?php echo e(route('blog.posts.category', ['slug' => $categoryRoot->slug])); ?>">
                                                    <?php echo e($categoryRoot->title); ?>

                                                </a>
                                            <?php endif; ?>
                                            <!-- category descendants:start -->
                                            <?php if($categoryRoot->descendants): ?>
                                                <?php echo $__env->make('blog.sub-categories', [
                                                    'categoryRoot' => $categoryRoot->descendants,
                                                    'category' => $category,
                                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php endif; ?>
                                            <!-- category descendants:end -->
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Title -->
    <h2 class="mt-4 mb-3">
        <?php echo e(trans('blog.title.category', ['title' => $category->title])); ?>

    </h2>

    <!-- Breadcrumb:start -->
    <?php echo e(Breadcrumbs::render('blog_posts_category', $category->title)); ?>

    <!-- Breadcrumb:end -->
    <div class="row">
        <div class="col-lg-8">
            <!-- Post list:start -->
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <!-- thumbnail:start -->
                                <?php if(file_exists(public_path($post->thumbnail))): ?>
                                    <!-- true -->
                                    <img class="card-img-top" src="<?php echo e(asset($post->thumbnail)); ?>"
                                        alt="<?php echo e($post->title); ?>">
                                <?php else: ?>
                                    <!-- else -->
                                    <img class="img-fluid rounded" src="http://placehold.it/750x300"
                                        alt="<?php echo e($post->title); ?>">
                                <?php endif; ?>
                                <!-- thumbnail:end -->
                            </div>
                            <div class="col-lg-6">
                                <h2 class="card-title"><?php echo e($post->title); ?></h2>
                                <p class="card-text"><?php echo e($post->description); ?></p>
                                <a href="<?php echo e(route('blog.posts.detail', ['slug' => $post->slug])); ?>"
                                    class="btn btn-primary">
                                    <?php echo e(trans('blog.button.read_more.value')); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <!-- empty -->
                <h3 class="text-center">
                    <?php echo e(trans('blog.no_data.posts')); ?>

                </h3>
            <?php endif; ?>
            <!-- Post list:end -->
        </div>
        <div class="col-md-4">
            <!-- Categories list:start -->
            <div class="card mb-1">
                <h5 class="card-header">
                    <?php echo e(trans('blog.widget.categories')); ?>

                </h5>
                <div class="card-body">
                    <ul class="list-unstyled">
                        <li>
                            <?php if($category->slug == $categoryRoot->slug): ?>
                                <?php echo e($categoryRoot->title); ?>

                            <?php else: ?>
                                <a href="<?php echo e(route('blog.posts.category', ['slug' => $categoryRoot->slug])); ?>">
                                    <?php echo e($categoryRoot->title); ?>

                                </a>
                            <?php endif; ?>
                            <!-- category descendants:start -->
                            <?php if($categoryRoot->descendants): ?>
                                <?php echo $__env->make('blog.sub-categories', [
                                    'categoryRoot' => $categoryRoot->descendants,
                                    'category' => $category,
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                            <!-- category descendants:end -->
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Categories list:end -->
        </div>
    </div>
    <!-- pagination:start -->
    <?php if($posts->hasPages()): ?>
        <div class="row">
            <div class="col">
                <?php echo e($posts->links('vendor.pagination.bootstrap-4')); ?>

            </div>
        </div>
    <?php endif; ?>
    <!-- pagination:end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smpn17tegal\resources\views/blog/posts-category.blade.php ENDPATH**/ ?>