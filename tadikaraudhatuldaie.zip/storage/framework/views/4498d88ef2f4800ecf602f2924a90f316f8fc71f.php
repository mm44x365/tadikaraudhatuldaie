<footer class="py-5 bg-dark mt-auto">
    <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; <?php echo e(config('app.name')); ?> 2021</p>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\dudu\resources\views/layouts/_blog/_footer.blade.php ENDPATH**/ ?>