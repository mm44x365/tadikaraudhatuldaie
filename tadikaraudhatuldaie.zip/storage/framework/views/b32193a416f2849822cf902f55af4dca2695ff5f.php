<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
    <div class="sb-sidenav-menu">
        <div class="nav">
            
            <a class="nav-link <?php echo e(set_active('dashboard.index')); ?>" href="<?php echo e(route('dashboard.index')); ?>">
                <div class="sb-nav-link-icon">
                    <i class="fas fa-tachometer-alt"></i>
                </div>
                <?php echo e(trans('dashboard.link.dashboard')); ?>

            </a>
            <div class="sb-sidenav-menu-heading"><?php echo e(trans('dashboard.menu.master')); ?></div>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage_posts')): ?>
                <a class="nav-link <?php echo e(set_active(['posts.index', 'posts.create', 'posts.edit', 'posts.show'])); ?>"
                    href="<?php echo e(route('posts.index')); ?>">
                    <div class="sb-nav-link-icon">
                        <i class="far fa-newspaper"></i>
                    </div>
                    <?php echo e(trans('dashboard.link.posts')); ?>

                </a>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage_categories')): ?>
                <a class="nav-link <?php echo e(set_active(['categories.index', 'categories.create', 'categories.edit', 'categories.show'])); ?>"
                    href="<?php echo e(route('categories.index')); ?>">
                    <div class="sb-nav-link-icon">
                        <i class="fas fa-bookmark"></i>
                    </div>
                    <?php echo e(trans('dashboard.link.categories')); ?>

                </a>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage_tags')): ?>
                <a class="nav-link <?php echo e(set_active(['tags.index', 'tags.create', 'tags.edit'])); ?>"
                    href="<?php echo e(route('tags.index')); ?>">
                    <div class="sb-nav-link-icon">
                        <i class="fas fa-tags"></i>
                    </div>
                    <?php echo e(trans('dashboard.link.tags')); ?>

                </a>
            <?php endif; ?>
            <div class="sb-sidenav-menu-heading"><?php echo e(trans('dashboard.menu.user_permission')); ?>

            </div>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage_users')): ?>
                <a class="nav-link <?php echo e(set_active(['users.index', 'users.show', 'users.create', 'users.edit'])); ?>"
                    href="<?php echo e(route('users.index')); ?>">
                    <div class="sb-nav-link-icon">
                        <i class="fas fa-user"></i>
                    </div>
                    <?php echo e(trans('dashboard.link.users')); ?>

                </a>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage_roles')): ?>
                <a class="nav-link <?php echo e(set_active(['roles.index', 'roles.show', 'roles.create', 'roles.edit'])); ?>"
                    href="<?php echo e(route('roles.index')); ?>">
                    <div class="sb-nav-link-icon">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <?php echo e(trans('dashboard.link.roles')); ?>

                </a>
            <?php endif; ?>
            <div class="sb-sidenav-menu-heading"><?php echo e(trans('dashboard.menu.setting')); ?></div>
            
            <a class="nav-link <?php echo e(set_active(['filemanager.index'])); ?>" href="<?php echo e(route('filemanager.index')); ?>">
                <div class="sb-nav-link-icon">
                    <i class="fas fa-photo-video"></i>
                </div>
                <?php echo e(trans('dashboard.link.file_manager')); ?>

            </a>
        </div>
    </div>
    <div class="sb-sidenav-footer">
        <div class="small"><?php echo e(trans('dashboard.label.logged_in_as')); ?></div>
        <!-- show username -->
        <?php echo e(Auth::user()->name); ?>

    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\tadikaraudhatuldaie\resources\views/layouts/_dashboard/sidebar.blade.php ENDPATH**/ ?>