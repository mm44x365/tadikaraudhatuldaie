<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>
        <?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?>
    </title>
    <!-- my-dashboard -->
    <link rel="stylesheet" href="<?php echo e(asset('vendor/my-dashboard/css/dashboard.css')); ?>">
    <!-- fontawesome -->
    <script src="<?php echo e(asset('vendor/fontawesome-free/js/all.min.js')); ?>"></script>
    <!-- icon flag -->
    <link rel="stylesheet" href="<?php echo e(asset('vendor/flag-icon-css/css/flag-icon.min.css')); ?>">
    
    <?php echo $__env->yieldPushContent('css-external'); ?>
    <?php echo $__env->yieldPushContent('css-internal'); ?>
</head>

<body>
    <!-- begin:navbar -->
    <?php echo $__env->make('layouts._dashboard.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end:navbar -->
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <!-- begin:sidebar -->
            <?php echo $__env->make('layouts._dashboard.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- end:sidebar -->
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid">
                    <h2 class="mt-2">
                        <!-- title -->
                        <?php echo $__env->yieldContent('title'); ?>
                    </h2>
                    <!-- begin:breadcrumbs -->
                    <?php echo $__env->yieldContent('breadcrumbs'); ?>
                    <!-- end:breadcrumbs -->

                    <!-- begin:content -->
                    <?php echo $__env->yieldContent('content'); ?>
                    <!-- end:content -->
                </div>
            </main>
            <!-- begin:footer -->
            <?php echo $__env->make('layouts._dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- end:footer -->
        </div>
    </div>
    <!-- scripts -->
    <!-- jquery -->
    <script src="<?php echo e(asset('vendor/jquery/jquery-3.6.0.min.js')); ?>"></script>
    <!-- bootstrap bundle -->
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- my-dashboard -->
    <script src="<?php echo e(asset('vendor/my-dashboard/js/dashboard.js')); ?>"></script>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->yieldPushContent('javascript-external'); ?>
    <?php echo $__env->yieldPushContent('javascript-internal'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\smpn17tegal\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>