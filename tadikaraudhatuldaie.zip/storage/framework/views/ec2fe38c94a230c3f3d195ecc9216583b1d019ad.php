
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('blog.title.tags')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h2 class="my-3">
        <?php echo e(trans('blog.title.tags')); ?>


    </h2>
    <!-- Breadcrumb:start -->
    <?php echo e(Breadcrumbs::render('blog_tags')); ?>

    <!-- Breadcrumb:end -->

    <!-- List tag -->
    <div class="row">
        <div class="col">
            <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <!-- true -->
                <a href="<?php echo e(route('blog.posts.tag', ['slug' => $tag->slug])); ?>"
                    class="badge badge-info py-3 px-5">#<?php echo e($tag->title); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <!-- false -->
                <h3 class="text-center">
                    <?php echo e(trans('blog.no_data.tags')); ?>

                </h3>
            <?php endif; ?>

        </div>
    </div>
    <!-- List tag -->

    <!-- pagination:start -->
    <?php if($tags->hasPages()): ?>
        <div class="row">
            <div class="col">
                <?php echo e($tags->links('vendor.pagination.bootstrap-4')); ?>

            </div>
        </div>
    <?php endif; ?>
    <!-- pagination:end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dudu\resources\views/blog/tags.blade.php ENDPATH**/ ?>