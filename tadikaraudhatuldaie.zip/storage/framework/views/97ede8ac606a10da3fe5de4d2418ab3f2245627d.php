<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid">
       <div class="d-flex align-items-center justify-content-between small">
          <div class="text-muted">Copyright © <?php echo e(config('app.name')); ?> 2022</div>
          <div>
             <a href="#">Privacy Policy</a>
             ·
             <a href="#">Terms &amp; Conditions</a>
          </div>
       </div>
    </div>
 </footer><?php /**PATH C:\xampp\htdocs\tadikaraudhatuldaie\resources\views/layouts/_dashboard/footer.blade.php ENDPATH**/ ?>