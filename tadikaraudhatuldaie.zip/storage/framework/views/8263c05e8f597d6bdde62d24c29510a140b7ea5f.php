
<?php $__env->startSection('title'); ?>
    Hubungi Kami
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="bg-half bg-light d-table w-100">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12 text-center">
                    <div class="page-next-level">
                        <h4 class="title">Hubungi Kami</h4>
                        <div class="page-next">
                            <nav aria-label="breadcrumb" class="d-inline-block">
                                <ul class="breadcrumb bg-white rounded shadow mb-0">
                                    <li class="breadcrumb-item"><a href="/">Beranda</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Hubungi Kami</li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="position-relative">
        <div class="shape overflow-hidden text-white">
            <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
            </svg>
        </div>
    </div>
    <section class="section pb-0">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="card contact-detail text-center border-0">
                        <div class="card-body p-0">
                            <div class="icon"><img src="<?php echo e(asset('vendor/smpn17/images/icon/call.svg')); ?>"
                                    class="avatar avatar-small" alt="" /></div>
                            <div class="content mt-3">
                                <h4 class="title font-weight-bold">Telepon</h4>
                                <p class="text-muted">Silahkan hubungi kami untuk pertanyaan, keluhan, dan informasi terkait
                                    <?php echo e(config('app.name')); ?> menggunakan nomor telepon berikut</p>
                                <a href="tel:0284321386" class="text-primary">0284321386</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <div class="card contact-detail text-center border-0">
                        <div class="card-body p-0">
                            <div class="icon"><img src="<?php echo e(asset('vendor/smpn17/images/icon/email.svg')); ?>"
                                    class="avatar avatar-small" alt="" /></div>
                            <div class="content mt-3">
                                <h4 class="title font-weight-bold">Email</h4>
                                <p class="text-muted">Hubungi kami kapan saja untuk pertanyaan, keluhan, dan informasi
                                    terkait S<?php echo e(config('app.name')); ?> melalui alamat email dibawah ini</p>
                                <a href="mailto:mail@gmail.com" class="text-primary">mail@gmail.com</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <div class="card contact-detail text-center border-0">
                        <div class="card-body p-0">
                            <div class="icon"><img src="<?php echo e(asset('vendor/smpn17/images/icon/location.svg')); ?>"
                                    class="avatar avatar-small" alt="" /></div>
                            <div class="content mt-3">
                                <h4 class="title font-weight-bold">Lokasi</h4>
                                <p class="text-muted">Jl. Gatot Subroto No.13, Sumurpanggang, Kec. Margadana, Kota Tegal,
                                    Jawa Tengah 52141</p>
                                <a href="https://goo.gl/maps/GHoDxuUTHEKp89Gp7" target="_BLANK"
                                    class="video-play-icon h6 text-primary">Lihat di Google Maps</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid mt-100 mt-60">
            <div class="row">
                <div class="col-12 p-0">
                    <div class="card map border-0">
                        <div class="card-body p-0"><iframe
                                src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15844.409398047716!2d109.1103018!3d-6.8783401!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x96faf0a74d3e1872!2sSMP%20Negeri%2017%20Tegal!5e0!3m2!1sid!2sid!4v1665464248667!5m2!1sid!2sid"
                                width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""
                                aria-hidden="false" tabindex="0"></iframe></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smpn17tegal\resources\views/landing/contact.blade.php ENDPATH**/ ?>