
<?php $__env->startSection('title'); ?>
    <?php echo e($post->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?>
    <?php echo e($post->description); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="bg-half bg-light d-table w-100">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12 text-center">
                    <div class="page-next-level">
                        <h4 class="title">Artikel</h4>
                        <div class="page-next">
                            <nav aria-label="breadcrumb" class="d-inline-block">
                                <?php echo e(Breadcrumbs::render('blog_posts', $post->title)); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-6">
                    <div class="card blog blog-detail border-0 shadow rounded">
                        <!-- thumbnail:start -->
                        <?php if(file_exists(public_path($post->thumbnail))): ?>
                            <!-- true -->
                            <img src="<?php echo e(asset($post->thumbnail)); ?>" class="img-fluid rounded-top"
                                alt="<?php echo e($post->title); ?>">
                        <?php else: ?>
                            <!-- else -->
                            <img class="img-fluid rounded-top" src="http://placehold.it/750x300" alt="<?php echo e($post->title); ?>">
                        <?php endif; ?>
                        <!-- thumbnail:end -->
                        <div class="card-body content">
                            <h4><?php echo e($post->title); ?></h4>
                            <h6><i class="mdi mdi-tag text-primary mr-1"></i>
                                <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('blog.posts.tag', ['slug' => $tag->slug])); ?>"
                                        class="badge badge-info py-2 px-4 my-1">
                                        #<?php echo e($tag->title); ?>

                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </h6>

                            <!-- Post Content:start -->
                            <div class="article-style">
                                <?php echo $post->content; ?>

                            </div>
                            <!-- Post Content:end -->

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <div class="card border-0 sidebar sticky-bar rounded shadow">
                        <div class="card-body">
                            <div id="search-outside">
                                <div class="widget mt-4 pb-2">
                                    <h4 class="widget-title"> <?php echo e(trans('blog.widget.categories')); ?></h4>
                                    <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('blog.posts.category', ['slug' => $category->slug])); ?>"
                                            class="badge badge-primary py-2 px-4 my-1">
                                            <?php echo e($category->title); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <!-- category list:end -->
                                </div>
                                <div class="widget mt-4 pb-2">
                                    <h4 class="widget-title"><?php echo e(trans('blog.widget.tags')); ?></h4>
                                    <!-- tag list:start -->
                                    <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('blog.posts.tag', ['slug' => $tag->slug])); ?>"
                                            class="badge badge-info py-2 px-4 my-1">
                                            #<?php echo e($tag->title); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <!-- tag list:end -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smpn17tegal\resources\views/blog/post-detail.blade.php ENDPATH**/ ?>