<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords"
        content="<?php echo e(config('app.name')); ?>, SMK NEPAL, SMKN 1 Pemalang, NEPAL, Negeri Pemalang, smkn1pml, SMK Pemalang">
    <meta name="description"
        content="<?php echo e(config('app.name')); ?> adalah satu-satunya Lembaga Pendidikan Menengah Kejuruan Negeri yang ada di Kecamatan Pemalang, Jawa Tengah.">
    <meta name="subject" content="Situs Pendidikan">
    <meta name="copyright" content="<?php echo e(config('app.name')); ?>">
    <meta name="language" content="Indonesia">
    <meta name="robots" content="index, follow">
    <meta name="Classification" content="Education">
    <meta name="author" content="Suluh Sulistiawan">
    <meta name="email" content="kuy@suluh.my.id">
    <meta name="website" content="https://suluh.my.id/">
    <meta name="owner" content="Suluh Sulistiawan">
    <meta name="url" content="https://suluh.my.id/">
    <meta name="identifier-URL" content="https://suluh.my.id/">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo e(config('app.name')); ?>">
    <meta property="og:description"
        content="<?php echo e(config('app.name')); ?> adalah satu-satunya Lembaga Pendidikan Menengah Kejuruan Negeri yang ada di Kecamatan Pemalang, Jawa Tengah.">
    <meta property="og:image" content="<?php echo e(asset('vendor/smpn17/images/banner1.png')); ?>">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:title" content="<?php echo e(config('app.name')); ?>">
    <meta property="twitter:description"
        content="<?php echo e(config('app.name')); ?> adalah satu-satunya Lembaga Pendidikan Menengah Kejuruan Negeri yang ada di Kecamatan Pemalang, Jawa Tengah.">
    <meta property="twitter:image" content="<?php echo e(asset('vendor/smpn17/images/banner1.png')); ?>">
    <meta name="category" content="Education">
    <meta name="coverage" content="Worldwide">
    <meta name="distribution" content="Global">
    <meta name="rating" content="General">
    <meta name="revisit-after" content="7 days">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Copyright" content="<?php echo e(config('app.name')); ?>">
    <meta http-equiv="imagetoolbar" content="no">
    <meta name="revisit-after" content="7">
    <meta name="webcrawlers" content="all">
    <meta name="rating" content="general">
    <meta name="spiders" content="all">
    <meta name="google-site-verification" content="J61GZ3fJ-haar2tsfmm-K_LKdv40kPks-ZgkSq7Pj-s">
    <meta itemprop="name" content="<?php echo e(config('app.name')); ?>">
    <meta itemprop="description"
        content="<?php echo e(config('app.name')); ?> adalah satu-satunya Lembaga Pendidikan Menengah Kejuruan Negeri yang ada di Kecamatan Pemalang, Jawa Tengah.">
    <meta itemprop="image" content="<?php echo e(asset('vendor/smpn17/images/banner1.png')); ?>">
    <link rel="shortcut icon" href="favicons/images-favicon.png">
    <link rel="alternate" href="/feed.xml" type="application/rss+xml" title="<?php echo e(config('app.name')); ?>">
    <link href="<?php echo e(asset('vendor/smpn17/css/css-bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('vendor/smpn17/css/css-materialdesignicons.min.css')); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.9/css/unicons.css">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/smpn17/css/css-owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/smpn17/css/css-owl.theme.default.min.css')); ?>">
    <link href="<?php echo e(asset('vendor/smpn17/css/css-magnific-popup.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('vendor/smpn17/css/css-style.css')); ?>" rel="stylesheet" type="text/css" id="theme-opt">
    <link href="<?php echo e(asset('vendor/smpn17/css/colors-default.css')); ?>" rel="stylesheet" id="color-opt">
    <link href="<?php echo e(asset('vendor/smpn17/css/css-custom.css')); ?>" rel="stylesheet" id="color-opt">
    <script type="text/javascript"
        src="https://platform-api.sharethis.com/js/sharethis.js#property=600c65b9fe6fa50012b7b7e8&amp;product=inline-share-buttons"
        async="async"></script>
</head>

<body>
    <!-- Navigation:start -->
    <?php echo $__env->make('layouts._landing._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Navigation:end -->


    <!-- Content:start -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- Content:end -->

    <!-- Footer:start -->
    <?php echo $__env->make('layouts._landing._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer:end -->

    <a href="#" rel="noindex, nofollow" class="btn btn-icon btn-soft-primary back-to-top"><i
            data-feather="arrow-up" class="icons"></i></a>
    <script src="<?php echo e(asset('vendor/smpn17/js/js-jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/smpn17/js/js-bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/smpn17/js/js-jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/smpn17/js/js-scrollspy.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/smpn17/js/js-owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/smpn17/js/js-owl.init.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/smpn17/js/js-jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/smpn17/js/s-isotope.js')); ?>j"></script>
    <script src="<?php echo e(asset('vendor/smpn17/js/js-portfolio.init.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/smpn17/js/js-feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/smpn17/js/monochrome-bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/smpn17/js/js-app.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/smpn17/js/js-search.js')); ?>"></script>
    <script id="dsq-count-scr" src="<?php echo e(asset('vendor/smpn17/js/count.js')); ?>" async></script>
    <script defer src="<?php echo e(asset('vendor/smpn17/js/beacon.min.js')); ?>"
        data-cf-beacon='{"token": "f15c13dabfff4f17b0f1d40cdd540e08"}'></script>
    <script src="<?php echo e(asset('vendor/smpn17/js/js-antibom.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\smpn17tegal\resources\views/layouts/landing.blade.php ENDPATH**/ ?>