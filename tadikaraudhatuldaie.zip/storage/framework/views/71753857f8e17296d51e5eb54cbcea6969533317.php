<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
   <meta charset="utf-8" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
   <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
   <link rel="stylesheet" href="<?php echo e(asset('vendor/my-auth/css/auth.css')); ?>">
</head>

<body class="bg-primary">
   <div id="layoutAuthentication">
      <div id="layoutAuthentication_content">
         <main>
            <div class="container">
               <div class="row justify-content-center">
                  <div class="col-lg-5">
                     <div class="card shadow-lg border-0 rounded-lg mt-5">
                        <div class="card-header">
                           <h3 class="text-center font-weight-light my-4">
                              <?php echo $__env->yieldContent('title'); ?>
                           </h3>
                        </div>
                        <div class="card-body">
                           <?php echo $__env->yieldContent('content'); ?>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </main>
      </div>
      <div id="layoutAuthentication_footer">
         <?php echo $__env->make('layouts._auth.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
   </div>
   <script src="<?php echo e(asset('vendor/jquery/jquery-3.6.0.min.js')); ?>"></script>
   <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
   <script src="<?php echo e(asset('vendor/my-auth/js/auth.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\tadikaraudhatuldaie\resources\views/layouts/auth.blade.php ENDPATH**/ ?>