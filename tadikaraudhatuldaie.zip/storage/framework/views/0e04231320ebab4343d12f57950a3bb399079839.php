<section class="bg-half-170 d-table w-100"
    style="background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('<?php echo e(asset('vendor/smpn17/images/banner1.png')); ?>'); background-position: center center; background-size: cover;"
    id="home">
    <div class="container">
        <div class="row position-relative align-items-center pt-4">
            <div class="col-lg-7 offset-lg-5">
                <div class="title-heading studio-home rounded bg-white shadow mt-5">
                    <h1 class="heading mb-3"><?php echo e(config('app.name')); ?></h1>
                    <p class="para-desc text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit..</p>
                    <div class="mt-4"><a href="ppdb.html" class="btn btn-primary mt-2 mr-2"><i
                                class="mdi mdi-handshake"></i> Info PPDB </a><a href="profil.html"
                            class="btn btn-outline-primary mt-2"><i class="mdi mdi-book-outline"></i> Profil
                            Sekolah </a></div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\smpn17tegal\resources\views/layouts/_landing/_banner.blade.php ENDPATH**/ ?>