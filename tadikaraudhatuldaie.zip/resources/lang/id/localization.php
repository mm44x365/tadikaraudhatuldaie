<?php
// Language : Indonesia
return [
    'id' => 'Indonesia (ID)',
    'en' => 'Inggris (EN)',
];
