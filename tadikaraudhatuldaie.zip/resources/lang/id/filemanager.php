<?php
/*
language : Indonesia
*/
return [
    'title' => [
        'index' => 'Manajer file'
    ],
    'form_control' => [
        'select' => [
            'type' => [
                'option' => [
                    'image' => 'Gambar',
                    'file' => 'Berkas',
                ]
            ]
        ]
    ],
    'button' => [
        'apply' => [
            'value' => 'Terapkan'
        ]
    ]
];
