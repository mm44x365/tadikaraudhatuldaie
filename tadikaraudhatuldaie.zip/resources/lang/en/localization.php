<?php
// Language : English
return [
    'id' => 'Indonesian (ID)',
    'en' => 'English (EN)',
];
