<?php
/*
language : English
*/
return [
    'title' => [
        'index' => 'File manager'
    ],
    'form_control' => [
        'select' => [
            'type' => [
                'option' => [
                    'image' => 'Image',
                    'file' => 'File',
                ]
            ]
        ]
    ],
    'button' => [
        'apply' => [
            'value' => 'Apply'
        ]
    ]
];
