<footer class="py-5 bg-dark mt-auto">
    <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; {{ config('app.name') }} 2021</p>
    </div>
</footer>
